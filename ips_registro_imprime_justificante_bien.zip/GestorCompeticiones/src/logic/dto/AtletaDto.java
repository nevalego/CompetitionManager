package logic.dto;

public class AtletaDto {
	public String nombre;
	public String apellido;
	public String email;
	public String dni;
	public String genero;
	public String diaNacimiento;
	public String mesNacimiento;
	public String a�oNacimiento;

}
