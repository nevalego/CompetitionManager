package logic.dto;

public class InscripcionDto {

}
